clear all;
close all;

curr_dir = pwd;
cd Models/Run12/Stage4/Run12Stage4/
Y = exist('Unique_Genes.txt');
if Y==2
    GeneList = textread('Unique_Genes.txt','%s');
end
Y = exist('GeneList_UnCmprss.txt');
if Y==2
    GeneList = textread('GeneList_UnCmprss.txt','%s');
end
for j=1:10
    PerClass{j} = textread(['GeneUnCmprssPerClass_',num2str(j),'.txt'],'%s');
end
cd ../../../

cd Run15/Stage5/Run15Stage5
Y = exist('Unique_Genes.txt');
if Y==2
    GeneList2 = textread('Unique_Genes.txt','%s');
end
Y = exist('GeneList_UnCmprss.txt');
if Y==2
    GeneList2 = textread('GeneList_UnCmprss.txt','%s');
end
GeneList = [GeneList;GeneList2];
GeneList = unique(GeneList);
for j=1:10
    PerClass2{j} = textread(['GeneUnCmprssPerClass_',num2str(j),'.txt'],'%s');
    PerClass{j} = [PerClass{j};PerClass2{j}];
    PerClass{j} = unique(PerClass{j});
end
cd ../../../

% cd Run22/Stage6/Run22Stage6
% Y = exist('Unique_Genes.txt');
% if Y==2
%     GeneList2 = textread('Unique_Genes.txt','%s');
% end
% Y = exist('GeneList_UnCmprss.txt');
% if Y==2
%     GeneList2 = textread('GeneList_UnCmprss.txt','%s');
% end
% GeneList = [GeneList;GeneList2];
% GeneList = unique(GeneList);
% for j=1:10
%     PerClass2{j} = textread(['GeneUnCmprssPerClass_',num2str(j),'.txt'],'%s');
%     PerClass{j} = [PerClass{j};PerClass2{j}];
%     PerClass{j} = unique(PerClass{j});
% end
% cd ../../../
% 
% cd Run23/Stage4/Run23Stage4
% Y = exist('Unique_Genes.txt');
% if Y==2
%     GeneList2 = textread('Unique_Genes.txt','%s');
% end
% Y = exist('GeneList_UnCmprss.txt');
% if Y==2
%     GeneList2 = textread('GeneList_UnCmprss.txt','%s');
% end
% GeneList = [GeneList;GeneList2];
% GeneList = unique(GeneList);
% for j=1:10
%     PerClass2{j} = textread(['GeneUnCmprssPerClass_',num2str(j),'.txt'],'%s');
%     PerClass{j} = [PerClass{j};PerClass2{j}];
%     PerClass{j} = unique(PerClass{j});
% end
% cd ../../../

cd(curr_dir);


fid = fopen('Combined_GeneList.txt','w');
for j=1:length(GeneList)
    fprintf(fid,'%s\n',GeneList{j});
end
fclose(fid);

for j=1:length(PerClass)
    fid = fopen(['Combined_PerClass_',num2str(j),'.txt'],'w');
    for k=1:length(PerClass{j})
        fprintf(fid,'%s\n',char(PerClass{j}(k)));
    end
    fclose(fid);
end

cd Data
genes = textread('tcga20180626.rnaseq_fpkm_uq.gene_id.txt','%s');
genes{1}=[];
genes(cellfun('isempty',genes))=[];
cd(curr_dir)

for j=1:length(GeneList)
    [r,Genes(j)]=max(strcmp(GeneList{j},genes));
end
save('Combined_Genes.mat','Genes');
