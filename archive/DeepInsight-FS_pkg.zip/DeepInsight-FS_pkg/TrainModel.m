% Train Model (training DeepInsight-FS)

clear all;
close all;

% run Prepare_Data.m %TCGA RNA-seq data will be prepared using tSNE algorithm
% see Prepare_Data.m for details

curr_dir = pwd;
addpath(curr_dir);

Parm.fid=fopen('Results.txt','a+');
Parm.UsePreviousModel = 0;

[upm,Mo,Init,Reg] = UsePreviousModel;
Parm.UsePreviousModel = upm; Parm.Momentum = Mo; Parm.InitialLearnRate = Init; Parm.L2Regularization = Reg;

[model, Norm]  = DeepInsight_train_CAM(Parm,2); % if you want to use Norm 2 only
%[model, Norm]  = DeepInsight_train_CAM(Parm); % best norm will be determined by the algorithm

if Norm==1
    Data = load('Out1.mat');
else
    Data = load('Out2.mat');
end
if size(Data.XTrain,3)<3
    Data.XTest = cat(3,Data.XTest,Data.XTest,Data.XTest);
end
Data = rmfield(Data,'XTrain');
Data = rmfield(Data,'YTrain');
Data = rmfield(Data,'XValidation');
Data = rmfield(Data,'YValidation');

Accuracy = DeepInsight_test_CAM(Data,model)

model.Norm=Norm;
save('model.mat','-struct','model','-v7.3');
fclose(Parm.fid);


