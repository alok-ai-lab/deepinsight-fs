function Accuracy = DeepInsight_test_CAM(dset,Out)
% Accuracy = DeepInsight_test_CAM(dset,Out)

%Out.bestIdx = BayesObject.IndexOfMinimumTrace(end);
%Out.fileName = BayesObject.UserDataTrace{Out.bestIdx};
current_dir=pwd;
cd DeepResults
savedStruct = load(Out.fileName);
%Out.valError = savedStruct.valError
cd(current_dir);

STest = size(dset.XTest,1:2);
inputSize = savedStruct.trainedNet.Layers(1).InputSize(1:2);

if STest(1)~= inputSize(1) | STest(2)~=inputSize(2)
    augT=augmentedImageDatastore(inputSize,dset.XTest);
    [YPredicted,probs] = classify(savedStruct.trainedNet,augT);
    testError = 1 - mean(YPredicted == dset.YTest);
    Accuracy = 1-testError;
else

    [YPredicted,probs] = classify(savedStruct.trainedNet,dset.XTest);
    testError = 1 - mean(YPredicted == dset.YTest);
    Accuracy = 1-testError;
end
end
