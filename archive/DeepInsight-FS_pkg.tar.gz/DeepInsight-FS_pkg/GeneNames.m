function GeneNames(rows,Comprss)

if nargin < 2
    Comprss = 1;
end

current_dir=pwd;
cd Data
genes = textread('tcga20180626.rnaseq_fpkm_uq.gene_id.txt','%s');
genes{1}=[];
genes(cellfun('isempty',genes))=[];
cd(current_dir)

if iscell(rows)==0
    if Comprss==1
        fid=fopen('GeneList.txt','w+');
    else
        fid=fopen('GeneList_UnCmprss.txt','w+');
    end

    for j=1:length(rows)
        fprintf(fid,'%s\n',genes{rows(j)});
    end
    fclose(fid);
else
    for k=1:length(rows)
        if Comprss==1
            fid=fopen(['GenePerClass_',num2str(k),'.txt'],'w+');
        else
            fid=fopen(['GeneUnCmprssPerClass_',num2str(k),'.txt'],'w+');
        end
        for j=1:length(rows{k})
            fprintf(fid,'%s\n',genes{rows{k}(j)});
        end
        fclose(fid);
    end
end

