function Out = DeepInsight_train_norm_CAM(XTrain,YTrain,XValidation,YValidation,Parm)
% Out = DeepInsight_train_norm_CAM(XTrain,YTrain,XValidation,YValidation,Parm)

if nargin <5
    Parm.UsePreviousModel = 0;
end

if Parm.UsePreviousModel == 0
    % change parameters as desired
    optimVars = [
        optimizableVariable('InitialLearnRate',[1e-5 1e-1],'Transform','log')
        optimizableVariable('Momentum',[0.8 0.95])
        optimizableVariable('L2Regularization',[1e-10 1e-2],'Transform','log')];

    ObjFcn = makeObjFcn_Squeezenet(XTrain,YTrain,XValidation,YValidation); % working-model

    current_dir=pwd;
    cd DeepResults
    BayesObject = bayesopt(ObjFcn,optimVars,...
        'MaxObj',50,...
        'MaxTime',24*60*60,...
        'IsObjectiveDeterministic',false,...    
        'UseParallel',false);
else
    optimVars = [
        optimizableVariable('InitialLearnRate',[Parm.InitialLearnRate Parm.InitialLearnRate+eps],'Transform','log')
        optimizableVariable('Momentum',[Parm.Momentum Parm.Momentum+eps])
        optimizableVariable('L2Regularization',[Parm.L2Regularization Parm.L2Regularization+eps],'Transform','log')];

    ObjFcn = makeObjFcn_Squeezenet(XTrain,YTrain,XValidation,YValidation); % working-model

    current_dir=pwd;
    cd DeepResults
    BayesObject = bayesopt(ObjFcn,optimVars,...
        'MaxObj',1,...
        'MaxTime',4*60*60,...
        'IsObjectiveDeterministic',false,...    
        'UseParallel',false);
end


Out.bestIdx = BayesObject.IndexOfMinimumTrace(end);
Out.fileName = BayesObject.UserDataTrace{Out.bestIdx};
savedStruct = load(Out.fileName);
Out.valError = savedStruct.valError
cd(current_dir);

%[YPredicted,probs] = classify(savedStruct.trainedNet,XTest);
%testError = 1 - mean(YPredicted == YTest)
%Accuracy = 1-testError
